# Service classes for Weather Manager

Currently this consists of services to:

- Access the Weather Underground Personal Weather Station API
- Access the Weather Manager MariaDb database