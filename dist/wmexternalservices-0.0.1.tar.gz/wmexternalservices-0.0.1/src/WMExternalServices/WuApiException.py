# Exception raised in the Weather Underground Api service
class WuApiException(Exception):
    pass
